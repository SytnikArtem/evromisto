# Sponsors & Backers

fullPage.js is being developed and maintained by [Alvaro Trigo](https://twitter.com/imac2).
Any help you can provide for its development and maintenance over time will be appreciated!

Here's the list of the persons/companies which are currently contributing to fullPage.js.
Thanks for it!

Want to be in the list? [Contact me](https://alvarotrigo.com/#contact) | [Become a patreon](https://www.patreon.com/fullpagejs)

## Bronze Sponsor ($30+ / month)

### Companies
<!-- bronce start-->
<table>
  <tbody>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.stackpath.com/" target="_blank" rel="nofollow">
          <img src="http://wallpapers-for-ipad.com/fullpage/imgs3/logos/stackpath3.png">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="http://www.browserstack.com/" target="_blank" rel="nofollow">
          <img src="http://wallpapers-for-ipad.com/fullpage/imgs3/logos/browserstack3.png">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://hostpresto.com/?utm_source=alvaro" target="_blank" rel="nofollow">
          <img src="http://wallpapers-for-ipad.com/fullpage/imgs3/logos/hostpresto3.png">
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://codepen.com" target="_blank" rel="nofollow">
          <img src="http://wallpapers-for-ipad.com/fullpage/imgs3/logos/codepen3.png">
        </a>
      </td>
    </tr>
  </tbody>
</table>
<!-- bronce end-->

### People
<table>
    <tbody>
      <tr>
        <td align="center" valign="middle">
          <a href="https://github.com/donsalvadori" target="_blank" rel="nofollow">
            <img src="http://wallpapers-for-ipad.com/fullpage/imgs3/avatars/donsalvadori.jpg">
          </a>
        </td>
      </tr>
    </tbody>
  </table>